from django.contrib import admin

from .models import JellybeanFlavor

# Register your models here.
admin.site.register(JellybeanFlavor)
