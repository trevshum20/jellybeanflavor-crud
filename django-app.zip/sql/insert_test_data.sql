INSERT INTO public.jellybeans_jellybeanflavor(
	name, description, "photoUrl")
	VALUES
    INSERT INTO public.jellybeans_jellybeanflavor(name, description, "photoUrl")
    VALUES
    ('Watermelon', 'Delicious nostaligic watermelon flavor', 'https://trevorshumway.com/images/jellybeans/watermelon.jpg'),
    ('Blue Raspberry', 'Tastes like Swedish Fish', 'https://trevorshumway.com/images/jellybeans/blueraspberry.jpeg'),
    ('Cherry', 'A classic', 'https://trevorshumway.com/images/jellybeans/cherry.jpg'),
    ('Pear', 'Slightly more exotic than usual', 'https://trevorshumway.com/images/jellybeans/pear.jpg'),
    ('Marshmallow', 'Mix with chocolate for a smore', 'https://trevorshumway.com/images/jellybeans/marshmallow.jpg'),
    ('Grape', 'Not for everyone but I love this flavor', 'https://trevorshumway.com/images/jellybeans/grape.jpg'),
    ('Popcorn', 'Gets stuck in your teeth less', 'https://trevorshumway.com/images/jellybeans/popcorn.jpg'),
    ('Cinnamon', 'Why is it spicy?', 'https://trevorshumway.com/images/jellybeans/cinnamon.jpg'),
    ('Strawberry', 'A fan favorite', 'https://trevorshumway.com/images/jellybeans/strawberry.jpeg'),
    ('Green Apple', 'Slightly sour', 'https://trevorshumway.com/images/jellybeans/green_apple.jpg'),
    ('Blue Cotton Candy', 'Very sweet and delicious', 'https://trevorshumway.com/images/jellybeans/blue_cotton_candy.jpeg'),
    ('Blackberry', 'Seems fresh and healthy', 'https://trevorshumway.com/images/jellybeans/blackberry.jpg'),
    ('Tutti Fruity', 'Nice combination of the best fruit flavors', 'https://trevorshumway.com/images/jellybeans/tutti_fruity.jpg'),
    ('Island Punch', 'Tastes like the drink!', 'https://trevorshumway.com/images/jellybeans/island_punch.jpg'),
    ('Orange', 'An unbeatable flavor', 'https://trevorshumway.com/images/jellybeans/orange.jpg'),
    ('Lemon Lime', 'Most people love this flavor', 'https://trevorshumway.com/images/jellybeans/lemon_lime.jpg');