This is a simple CRUD app built for the final interview for the Software Developer role at the BYU Harold B. Lee Library

This CRUD application allows an internal admin to manage available jelly bean flavors. It is part of a job interview project with the BYU Harold B. Lee Library, and I am incredibly excited about this opportunity!

This app provides functionality to Create, Read, Update, and Delete jelly bean flavors, ensuring a simple and efficient way to keep the library’s jelly bean collection up to date.